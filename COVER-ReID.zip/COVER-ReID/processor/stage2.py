import logging
import os
import time
from datetime import timedelta

import torch
import torch.distributed as dist
import torch.nn as nn
from torch.cuda import amp

from processor.cover import (
    build_clip_prompt_features,
    build_counterfactual_batch,
    visibility_supervision,
)
from utils.meter import AverageMeter
from utils.metrics import R1_mAP_eval


def _identity_text_features(model, num_classes, batch_size, device):
    features = []
    with torch.no_grad():
        for start in range(0, num_classes, batch_size):
            labels = torch.arange(start, min(start + batch_size, num_classes), device=device)
            with amp.autocast(enabled=True):
                features.append(model(label=labels, get_text=True).cpu())
    return torch.cat(features, dim=0).to(device)


def _prepare_side_information(cfg, camera_ids, view_ids, device):
    camera_ids = camera_ids.to(device) if cfg.MODEL.SIE_CAMERA else None
    view_ids = view_ids.to(device) if cfg.MODEL.SIE_VIEW else None
    return camera_ids, view_ids


def _evaluate(cfg, model, val_loader, evaluator, device):
    evaluator.reset()
    model.eval()
    for images, pids, camids, camera_ids, view_ids, _ in val_loader:
        with torch.no_grad():
            images = images.to(device)
            camera_ids, view_ids = _prepare_side_information(
                cfg, camera_ids, view_ids, device
            )
            features = model(images, cam_label=camera_ids, view_label=view_ids)
            evaluator.update((features, pids, camids))
    return evaluator.compute()


def do_train_stage2(
    cfg,
    model,
    center_criterion,
    train_loader_stage2,
    val_loader,
    optimizer,
    optimizer_center,
    scheduler,
    loss_fn,
    num_query,
    local_rank,
):
    device = torch.device("cuda", local_rank)
    logger = logging.getLogger("cover.train")
    logger.info("Starting COVER stage-2 training")

    model.to(device)
    if torch.cuda.device_count() > 1:
        model = nn.DataParallel(model)
        num_classes = model.module.num_classes
    else:
        num_classes = model.num_classes

    identity_text = _identity_text_features(
        model, num_classes, cfg.SOLVER.STAGE2.IMS_PER_BATCH, device
    )
    pair_text = build_clip_prompt_features(model, device, cfg)
    base_model = model.module if hasattr(model, "module") else model
    grid_size = (base_model.h_resolution, base_model.w_resolution)

    evaluator = R1_mAP_eval(
        num_query, max_rank=50, feat_norm=cfg.TEST.FEAT_NORM
    )
    scaler = amp.GradScaler()
    total_meter = AverageMeter()
    clean_meter = AverageMeter()
    counterfactual_meter = AverageMeter()
    visibility_meter = AverageMeter()
    accuracy_meter = AverageMeter()
    pair_score_meter = AverageMeter()
    start_time = time.monotonic()

    for epoch in range(1, cfg.SOLVER.STAGE2.MAX_EPOCHS + 1):
        epoch_start = time.time()
        for meter in (
            total_meter,
            clean_meter,
            counterfactual_meter,
            visibility_meter,
            accuracy_meter,
            pair_score_meter,
        ):
            meter.reset()

        scheduler.step()
        model.train()
        for iteration, (images, labels, camera_ids, view_ids) in enumerate(
            train_loader_stage2, start=1
        ):
            optimizer.zero_grad()
            optimizer_center.zero_grad()
            images = images.to(device)
            labels = labels.to(device)
            camera_ids, view_ids = _prepare_side_information(
                cfg, camera_ids, view_ids, device
            )

            with amp.autocast(enabled=True):
                clean_scores, clean_features, clean_projected, clean_tokens = model(
                    images,
                    label=labels,
                    cam_label=camera_ids,
                    view_label=view_ids,
                    return_patch_tokens=True,
                )
                clean_logits = clean_projected @ identity_text.t()
                clean_loss = loss_fn(
                    clean_scores,
                    clean_features,
                    labels,
                    camera_ids,
                    clean_logits,
                )

                counterfactual_images, masks, selection_stats = build_counterfactual_batch(
                    images,
                    labels,
                    clean_tokens.detach(),
                    clean_projected.detach(),
                    pair_text,
                    cfg,
                    grid_size,
                )
                (
                    counterfactual_scores,
                    counterfactual_features,
                    counterfactual_projected,
                    counterfactual_tokens,
                ) = model(
                    counterfactual_images,
                    label=labels,
                    cam_label=camera_ids,
                    view_label=view_ids,
                    return_patch_tokens=True,
                )
                counterfactual_logits = counterfactual_projected @ identity_text.t()
                counterfactual_loss = loss_fn(
                    counterfactual_scores,
                    counterfactual_features,
                    labels,
                    camera_ids,
                    counterfactual_logits,
                )
                visibility_loss, _ = visibility_supervision(
                    model,
                    clean_tokens,
                    counterfactual_tokens,
                    masks,
                    cfg,
                    grid_size,
                )
                loss = (
                    clean_loss
                    + cfg.COVER.OCCLUSION.REID_WEIGHT * counterfactual_loss
                    + cfg.COVER.CVPA.VIS_LOSS_WEIGHT * visibility_loss
                )

            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()

            if "center" in cfg.MODEL.METRIC_LOSS_TYPE:
                for parameter in center_criterion.parameters():
                    parameter.grad.data *= 1.0 / cfg.SOLVER.STAGE2.CENTER_LOSS_WEIGHT
                scaler.step(optimizer_center)
                scaler.update()

            accuracy = (clean_logits.argmax(1) == labels).float().mean()
            batch_size = images.shape[0]
            total_meter.update(loss.item(), batch_size)
            clean_meter.update(clean_loss.item(), batch_size)
            counterfactual_meter.update(counterfactual_loss.item(), batch_size)
            visibility_meter.update(visibility_loss.item(), batch_size)
            accuracy_meter.update(accuracy.item(), batch_size)
            if selection_stats["count"]:
                pair_score_meter.update(
                    selection_stats["pair_score"], selection_stats["count"]
                )

            torch.cuda.synchronize()
            if iteration % cfg.SOLVER.STAGE2.LOG_PERIOD == 0:
                logger.info(
                    "Epoch[%d] Iteration[%d/%d] Loss: %.3f, Clean: %.3f, "
                    "Counterfactual: %.3f, Visibility: %.3f, Acc: %.3f, "
                    "PairScore: %.3f, LR: %.2e",
                    epoch,
                    iteration,
                    len(train_loader_stage2),
                    total_meter.avg,
                    clean_meter.avg,
                    counterfactual_meter.avg,
                    visibility_meter.avg,
                    accuracy_meter.avg,
                    pair_score_meter.avg,
                    scheduler.get_lr()[0],
                )

        elapsed = time.time() - epoch_start
        logger.info(
            "Epoch %d complete, %.3f s/batch",
            epoch,
            elapsed / max(len(train_loader_stage2), 1),
        )

        if epoch % cfg.SOLVER.STAGE2.CHECKPOINT_PERIOD == 0:
            if not cfg.MODEL.DIST_TRAIN or dist.get_rank() == 0:
                state = model.module.state_dict() if hasattr(model, "module") else model.state_dict()
                torch.save(state, os.path.join(cfg.OUTPUT_DIR, f"COVER_epoch_{epoch}.pth"))

        eval_epochs = set(int(value) for value in cfg.SOLVER.STAGE2.EVAL_EPOCHS)
        should_evaluate = (
            epoch in eval_epochs
            if eval_epochs
            else epoch % cfg.SOLVER.STAGE2.EVAL_PERIOD == 0
        )
        if should_evaluate and (not cfg.MODEL.DIST_TRAIN or dist.get_rank() == 0):
            cmc, mean_ap, _, _, _, _, _ = _evaluate(
                cfg, model, val_loader, evaluator, device
            )
            logger.info("Evaluation - Epoch: %d, mAP: %.1f%%", epoch, mean_ap * 100)
            for rank in (1, 5, 10):
                logger.info("CMC Rank-%d: %.1f%%", rank, cmc[rank - 1] * 100)
            torch.cuda.empty_cache()

    logger.info(
        "Stage-2 running time: %s",
        timedelta(seconds=time.monotonic() - start_time),
    )


def do_inference(cfg, model, val_loader, num_query):
    device = torch.device("cuda")
    logger = logging.getLogger("cover.test")
    evaluator = R1_mAP_eval(
        num_query, max_rank=50, feat_norm=cfg.TEST.FEAT_NORM
    )
    evaluator.reset()

    if torch.cuda.device_count() > 1:
        model = nn.DataParallel(model)
    model.to(device)
    model.eval()

    for images, pids, camids, camera_ids, view_ids, _ in val_loader:
        with torch.no_grad():
            images = images.to(device)
            camera_ids, view_ids = _prepare_side_information(
                cfg, camera_ids, view_ids, device
            )
            features = model(images, cam_label=camera_ids, view_label=view_ids)
            evaluator.update((features, pids, camids))

    cmc, mean_ap, _, _, _, _, _ = evaluator.compute()
    logger.info("mAP: %.1f%%", mean_ap * 100)
    for rank in (1, 5, 10):
        logger.info("CMC Rank-%d: %.1f%%", rank, cmc[rank - 1] * 100)
    return cmc[0], cmc[4], mean_ap
