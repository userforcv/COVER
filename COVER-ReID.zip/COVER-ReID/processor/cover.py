import math
import random

import torch
import torch.nn.functional as F

from model.clip import clip


def _base_model(model):
    return model.module if hasattr(model, "module") else model


def build_clip_prompt_features(model, device, cfg):
    """Encode the fixed source/target prompts used by COVER selection."""
    occ_cfg = cfg.COVER.OCCLUSION
    groups = {
        "source_positive": list(occ_cfg.SOURCE_POSITIVE_PROMPTS),
        "source_negative": list(occ_cfg.SOURCE_NEGATIVE_PROMPTS),
        "target_positive": list(occ_cfg.TARGET_POSITIVE_PROMPTS),
        "target_negative": list(occ_cfg.TARGET_NEGATIVE_PROMPTS),
    }
    if not groups["source_positive"] or not groups["source_negative"]:
        raise ValueError("COVER requires positive and negative source prompts.")
    if not groups["target_positive"]:
        raise ValueError("COVER requires positive target prompts.")

    prompts = []
    slices = {}
    for name, values in groups.items():
        start = len(prompts)
        prompts.extend(values)
        slices[name] = slice(start, len(prompts))

    tokenized = clip.tokenize(prompts).to(device)
    with torch.no_grad():
        features = _base_model(model).encode_text_tokens(tokenized)
        features = F.normalize(features.float(), dim=-1)
    return {name: features[index] for name, index in slices.items()}


def _sample_patch_size(height, width, area_range, aspect_range):
    image_area = height * width
    for _ in range(20):
        target_area = random.uniform(*area_range) * image_area
        aspect_ratio = random.uniform(*aspect_range)
        patch_h = int(round(math.sqrt(target_area * aspect_ratio)))
        patch_w = int(round(math.sqrt(target_area / aspect_ratio)))
        if 1 <= patch_h < height and 1 <= patch_w < width:
            return patch_h, patch_w
    return max(1, int(height * 0.3)), max(1, int(width * 0.3))


def _choose_donor(index, labels):
    candidates = torch.nonzero(labels != labels[index], as_tuple=False).flatten()
    if candidates.numel() == 0:
        return None
    choice = torch.randint(candidates.numel(), (1,), device=labels.device)
    return int(candidates[choice].item())


def _randint(low, high):
    low = int(round(low))
    high = int(round(high))
    return low if high <= low else random.randint(low, high)


def _sample_edge_box(height, width, patch_h, patch_w, edge_ratio):
    edge_h = max(patch_h, int(round(height * edge_ratio)))
    edge_w = max(patch_w, int(round(width * edge_ratio)))
    regions = [
        (0, edge_h - patch_h, 0, width - patch_w),
        (height - edge_h, height - patch_h, 0, width - patch_w),
        (0, height - patch_h, 0, edge_w - patch_w),
        (0, height - patch_h, width - edge_w, width - patch_w),
    ]
    y_min, y_max, x_min, x_max = random.choice(regions)
    return _randint(y_min, y_max), _randint(x_min, x_max)


def _sample_body_box(height, width, patch_h, patch_w, x_range, y_range):
    x_min = max(0, width * x_range[0] - patch_w / 2)
    x_max = min(width - patch_w, width * x_range[1] - patch_w / 2)
    y_min = max(0, height * y_range[0] - patch_h / 2)
    y_max = min(height - patch_h, height * y_range[1] - patch_h / 2)
    if x_max < x_min or y_max < y_min:
        return random.randint(0, height - patch_h), random.randint(0, width - patch_w)
    return _randint(y_min, y_max), _randint(x_min, x_max)


def _pool_box_tokens(tokens, box, image_size, grid_size):
    y, x, patch_h, patch_w = box
    height, width = image_size
    grid_h, grid_w = grid_size
    if tokens.shape[0] != grid_h * grid_w:
        raise ValueError("Token count and model patch grid are inconsistent.")

    row_start = max(0, min(grid_h - 1, int(math.floor(y * grid_h / height))))
    row_end = max(
        row_start + 1,
        min(grid_h, int(math.ceil((y + patch_h) * grid_h / height))),
    )
    col_start = max(0, min(grid_w - 1, int(math.floor(x * grid_w / width))))
    col_end = max(
        col_start + 1,
        min(grid_w, int(math.ceil((x + patch_w) * grid_w / width))),
    )
    grid = tokens.reshape(grid_h, grid_w, -1)
    return grid[row_start:row_end, col_start:col_end].reshape(-1, tokens.shape[-1]).mean(0)


def _source_score(tokens, box, image_size, grid_size, text_features):
    feature = F.normalize(_pool_box_tokens(tokens, box, image_size, grid_size).float(), dim=0)
    positive = torch.matmul(text_features["source_positive"], feature).mean()
    negative = torch.matmul(text_features["source_negative"], feature).mean()
    return positive - negative


def _target_score(tokens, global_feature, box, image_size, grid_size, text_features, cfg):
    feature = F.normalize(_pool_box_tokens(tokens, box, image_size, grid_size).float(), dim=0)
    score = torch.matmul(text_features["target_positive"], feature).mean()
    target_negative = text_features["target_negative"]
    if target_negative.numel() > 0 and cfg.TARGET_NEG_WEIGHT > 0:
        score = score - cfg.TARGET_NEG_WEIGHT * torch.matmul(target_negative, feature).mean()
    identity_score = torch.dot(feature, F.normalize(global_feature.float(), dim=0))
    return score + cfg.TARGET_ID_WEIGHT * identity_score


def _transfer_penalty(images, target_index, donor_index, source_box, target_box, min_visible):
    sy, sx, patch_h, patch_w = source_box
    ty, tx, _, _ = target_box
    source = images[donor_index, :, sy:sy + patch_h, sx:sx + patch_w]
    target = images[target_index, :, ty:ty + patch_h, tx:tx + patch_w]
    color_penalty = (source.float().mean((1, 2)) - target.float().mean((1, 2))).abs().mean()
    visible_ratio = 1.0 - patch_h * patch_w / float(images.shape[-2] * images.shape[-1])
    return color_penalty + source.new_tensor(max(0.0, min_visible - visible_ratio))


def _select_pair(
    images,
    target_index,
    donor_index,
    patch_size,
    source_tokens,
    target_tokens,
    target_global,
    text_features,
    cfg,
    grid_size,
):
    patch_h, patch_w = patch_size
    height, width = images.shape[-2:]
    image_size = (height, width)
    source_candidates = []
    target_candidates = []

    for _ in range(cfg.NUM_SOURCE_CANDIDATES):
        y, x = _sample_edge_box(height, width, patch_h, patch_w, cfg.EDGE_RATIO)
        box = (y, x, patch_h, patch_w)
        source_candidates.append(
            (_source_score(source_tokens, box, image_size, grid_size, text_features), box)
        )
    for _ in range(cfg.NUM_TARGET_CANDIDATES):
        y_range = random.choice(list(cfg.BODY_PART_RANGES))
        y, x = _sample_body_box(
            height, width, patch_h, patch_w, cfg.BODY_X_RANGE, y_range
        )
        box = (y, x, patch_h, patch_w)
        target_candidates.append(
            (
                _target_score(
                    target_tokens,
                    target_global,
                    box,
                    image_size,
                    grid_size,
                    text_features,
                    cfg,
                ),
                box,
            )
        )

    pairs = []
    for source_score, source_box in source_candidates:
        for target_score, target_box in target_candidates:
            hard_score = torch.relu(source_score) * torch.relu(target_score)
            penalty = _transfer_penalty(
                images,
                target_index,
                donor_index,
                source_box,
                target_box,
                cfg.MIN_VISIBLE_RATIO,
            )
            score = (
                cfg.SOURCE_WEIGHT * source_score
                + cfg.TARGET_WEIGHT * target_score
                + cfg.HARD_WEIGHT * hard_score
                - cfg.UNREAL_WEIGHT * penalty
            )
            pairs.append((score, source_box, target_box))

    scores = torch.stack([pair[0] for pair in pairs]).float()
    topk = min(cfg.TOPK, len(pairs))
    top_scores, top_indices = torch.topk(scores, topk)
    probabilities = torch.softmax(top_scores / cfg.TEMPERATURE, dim=0).cpu().tolist()
    selected_rank = random.choices(range(topk), weights=probabilities, k=1)[0]
    selected = pairs[int(top_indices[selected_rank].item())]
    return selected[1], selected[2], float(selected[0].detach().item())


@torch.no_grad()
def build_counterfactual_batch(
    images,
    labels,
    patch_tokens,
    global_features,
    text_features,
    cfg,
    grid_size,
):
    """Construct cross-identity edge-to-body interventions and exact masks."""
    occ_cfg = cfg.COVER.OCCLUSION
    counterfactual = images.clone()
    mask = images.new_zeros((images.shape[0], 1, images.shape[2], images.shape[3]))
    selected_scores = []

    for target_index in range(images.shape[0]):
        if random.random() > occ_cfg.PROB:
            continue
        donor_index = _choose_donor(target_index, labels)
        if donor_index is None:
            continue

        patch_size = _sample_patch_size(
            images.shape[2],
            images.shape[3],
            list(occ_cfg.AREA_RANGE),
            list(occ_cfg.ASPECT_RANGE),
        )
        source_box, target_box, score = _select_pair(
            images,
            target_index,
            donor_index,
            patch_size,
            patch_tokens[donor_index],
            patch_tokens[target_index],
            global_features[target_index],
            text_features,
            occ_cfg,
            grid_size,
        )
        sy, sx, patch_h, patch_w = source_box
        ty, tx, _, _ = target_box
        patch = images[donor_index, :, sy:sy + patch_h, sx:sx + patch_w]
        counterfactual[target_index, :, ty:ty + patch_h, tx:tx + patch_w] = patch
        mask[target_index, :, ty:ty + patch_h, tx:tx + patch_w] = 1.0
        selected_scores.append(score)

    mean_score = sum(selected_scores) / len(selected_scores) if selected_scores else 0.0
    return counterfactual, mask, {"pair_score": mean_score, "count": len(selected_scores)}


def mask_to_visibility(mask, grid_size):
    token_occlusion = F.adaptive_avg_pool2d(mask.float(), grid_size).squeeze(1)
    token_occlusion = token_occlusion.flatten(1).clamp(0.0, 1.0)
    return (1.0 - token_occlusion).clamp(0.0, 1.0), token_occlusion


def visibility_supervision(model, clean_tokens, counterfactual_tokens, mask, cfg, grid_size):
    """Weighted mask supervision plus clean-view calibration."""
    cvpa_cfg = cfg.COVER.CVPA
    base_model = _base_model(model)
    target, token_occlusion = mask_to_visibility(mask, grid_size)
    logits = base_model.visibility_logits(counterfactual_tokens)
    target = target.to(device=logits.device, dtype=logits.dtype)
    weights = 1.0 + cvpa_cfg.OCCLUSION_FOCUS * token_occlusion.to(logits)
    element_loss = F.binary_cross_entropy_with_logits(logits.float(), target.float(), reduction="none")
    occluded_loss = (element_loss * weights.float()).sum() / (weights.sum() + cvpa_cfg.EPS)

    clean_logits = base_model.visibility_logits(clean_tokens)
    clean_target = torch.ones_like(clean_logits)
    clean_loss = F.binary_cross_entropy_with_logits(clean_logits.float(), clean_target.float())
    total = (occluded_loss + cvpa_cfg.CLEAN_WEIGHT * clean_loss) / (1.0 + cvpa_cfg.CLEAN_WEIGHT)

    prediction = torch.sigmoid(logits.detach().float())
    return total, {
        "prediction": prediction.mean(),
        "target": target.detach().float().mean(),
        "occlusion": token_occlusion.detach().float().mean(),
    }
