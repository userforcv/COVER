import logging
import os
import time
from datetime import timedelta

import torch
import torch.distributed as dist
import torch.nn as nn
from torch.cuda import amp

from loss.supcontrast import SupConLoss
from utils.meter import AverageMeter


def do_train_stage1(
    cfg,
    model,
    train_loader_stage1,
    optimizer,
    scheduler,
    local_rank,
):
    checkpoint_period = cfg.SOLVER.STAGE1.CHECKPOINT_PERIOD
    device = torch.device("cuda", local_rank)
    epochs = cfg.SOLVER.STAGE1.MAX_EPOCHS
    log_period = cfg.SOLVER.STAGE1.LOG_PERIOD 

    logger = logging.getLogger("cover.train")
    logger.info("Starting COVER stage-1 prompt learning")
    model.to(device)
    if torch.cuda.device_count() > 1:
        logger.info("Using %d GPUs for training", torch.cuda.device_count())
        model = nn.DataParallel(model)

    loss_meter = AverageMeter()
    scaler = amp.GradScaler()
    contrastive_loss = SupConLoss(device)
    start_time = time.monotonic()
    image_features = []
    labels = []
    with torch.no_grad():
        for images, identities, _, _ in train_loader_stage1:
            images = images.to(device)
            identities = identities.to(device)
            with amp.autocast(enabled=True):
                batch_features = model(images, identities, get_image=True)
            labels.extend(identities)
            image_features.extend(batch_features.cpu())

        labels = torch.stack(labels).to(device)
        image_features = torch.stack(image_features).to(device)

    batch_size = cfg.SOLVER.STAGE1.IMS_PER_BATCH
    num_images = labels.shape[0]

    for epoch in range(1, epochs + 1):
        loss_meter.reset()
        scheduler.step(epoch)
        model.train()

        order = torch.randperm(num_images, device=device)
        num_iterations = (num_images + batch_size - 1) // batch_size
        for iteration, start in enumerate(range(0, num_images, batch_size), start=1):
            optimizer.zero_grad()
            indices = order[start:start + batch_size]
            target = labels[indices]
            batch_features = image_features[indices]
            with amp.autocast(enabled=True):
                text_features = model(label=target, get_text=True)
            loss_i2t = contrastive_loss(batch_features, text_features, target, target)
            loss_t2i = contrastive_loss(text_features, batch_features, target, target)
            loss = loss_i2t + loss_t2i

            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()

            loss_meter.update(loss.item(), target.shape[0])

            torch.cuda.synchronize()
            if iteration % log_period == 0:
                logger.info(
                    "Epoch[%d] Iteration[%d/%d] Loss: %.3f, Base LR: %.2e",
                    epoch,
                    iteration,
                    num_iterations,
                    loss_meter.avg,
                    scheduler._get_lr(epoch)[0],
                )

        if epoch % checkpoint_period == 0:
            if not cfg.MODEL.DIST_TRAIN or dist.get_rank() == 0:
                state = model.module.state_dict() if hasattr(model, "module") else model.state_dict()
                path = os.path.join(cfg.OUTPUT_DIR, f"COVER_stage1_epoch_{epoch}.pth")
                torch.save(state, path)

    logger.info(
        "Stage-1 running time: %s",
        timedelta(seconds=time.monotonic() - start_time),
    )
