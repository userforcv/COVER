import argparse
import os
import random

import numpy as np
import torch

from config import cfg
from datasets.make_dataloader import make_dataloader
from loss.make_loss import make_loss
from model.cover_reid import make_model
from processor.stage1 import do_train_stage1
from processor.stage2 import do_train_stage2
from solver.lr_scheduler import WarmupMultiStepLR
from solver.make_optimizer_prompt import make_optimizer_1stage, make_optimizer_2stage
from solver.scheduler_factory import create_scheduler
from utils.logger import setup_logger


def set_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = True


def parse_args():
    parser = argparse.ArgumentParser(description="Train COVER-ReID")
    parser.add_argument("--config-file", default="configs/cover_occ_duke.yml")
    parser.add_argument("--local-rank", "--local_rank", default=0, type=int)
    parser.add_argument("opts", default=None, nargs=argparse.REMAINDER)
    return parser.parse_args()


def main():
    args = parse_args()
    cfg.merge_from_file(args.config_file)
    cfg.merge_from_list(args.opts)
    cfg.freeze()
    os.environ.setdefault("CUDA_VISIBLE_DEVICES", cfg.MODEL.DEVICE_ID)
    set_seed(cfg.SOLVER.SEED)

    if cfg.MODEL.DIST_TRAIN:
        torch.cuda.set_device(args.local_rank)
        torch.distributed.init_process_group(backend="nccl", init_method="env://")

    os.makedirs(cfg.OUTPUT_DIR, exist_ok=True)
    logger = setup_logger("cover", cfg.OUTPUT_DIR, if_train=True)
    logger.info("Configuration:\n%s", cfg)

    loaders = make_dataloader(cfg)
    train_loader_stage2, train_loader_stage1, val_loader = loaders[:3]
    num_query, num_classes, camera_num, view_num = loaders[3:]
    model = make_model(cfg, num_classes, camera_num, view_num)
    loss_func, center_criterion = make_loss(cfg, num_classes)

    if cfg.SOLVER.STAGE1.SKIP:
        if not cfg.SOLVER.STAGE1.WEIGHT:
            raise ValueError("STAGE1.SKIP requires STAGE1.WEIGHT.")
        model.load_param(cfg.SOLVER.STAGE1.WEIGHT)
    else:
        optimizer_stage1 = make_optimizer_1stage(cfg, model)
        scheduler_stage1 = create_scheduler(
            optimizer_stage1,
            num_epochs=cfg.SOLVER.STAGE1.MAX_EPOCHS,
            lr_min=cfg.SOLVER.STAGE1.LR_MIN,
            warmup_lr_init=cfg.SOLVER.STAGE1.WARMUP_LR_INIT,
            warmup_t=cfg.SOLVER.STAGE1.WARMUP_EPOCHS,
            noise_range=None,
        )
        do_train_stage1(
            cfg,
            model,
            train_loader_stage1,
            optimizer_stage1,
            scheduler_stage1,
            args.local_rank,
        )

    optimizer_stage2, optimizer_center = make_optimizer_2stage(
        cfg, model, center_criterion
    )
    scheduler_stage2 = WarmupMultiStepLR(
        optimizer_stage2,
        cfg.SOLVER.STAGE2.STEPS,
        cfg.SOLVER.STAGE2.GAMMA,
        cfg.SOLVER.STAGE2.WARMUP_FACTOR,
        cfg.SOLVER.STAGE2.WARMUP_ITERS,
        cfg.SOLVER.STAGE2.WARMUP_METHOD,
    )
    do_train_stage2(
        cfg,
        model,
        center_criterion,
        train_loader_stage2,
        val_loader,
        optimizer_stage2,
        optimizer_center,
        scheduler_stage2,
        loss_func,
        num_query,
        args.local_rank,
    )


if __name__ == "__main__":
    main()
