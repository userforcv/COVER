#!/usr/bin/env bash
set -euo pipefail

DATA_ROOT="${DATA_ROOT:-./data}"
OUTPUT_DIR="${OUTPUT_DIR:-outputs/cover_occ_duke}"
GPU_ID="${GPU_ID:-0}"

export CUDA_VISIBLE_DEVICES="$GPU_ID"
python train.py --config-file configs/cover_occ_duke.yml \
  DATASETS.ROOT_DIR "$DATA_ROOT" \
  OUTPUT_DIR "$OUTPUT_DIR" \
  "$@"
