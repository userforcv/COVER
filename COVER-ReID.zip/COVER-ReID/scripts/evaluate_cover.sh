#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -lt 1 ]; then
  echo "Usage: $0 CHECKPOINT [additional config overrides]" >&2
  exit 1
fi

CHECKPOINT="$1"
shift
DATA_ROOT="${DATA_ROOT:-./data}"
OUTPUT_DIR="${OUTPUT_DIR:-outputs/evaluation}"
GPU_ID="${GPU_ID:-0}"

export CUDA_VISIBLE_DEVICES="$GPU_ID"
python test.py --config-file configs/cover_occ_duke.yml \
  DATASETS.ROOT_DIR "$DATA_ROOT" \
  OUTPUT_DIR "$OUTPUT_DIR" \
  TEST.WEIGHT "$CHECKPOINT" \
  "$@"
