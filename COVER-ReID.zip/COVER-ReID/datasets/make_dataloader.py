import torch
import torch.distributed as dist
import torchvision.transforms as transforms
from timm.data.random_erasing import RandomErasing
from torch.utils.data import DataLoader

from .bases import ImageDataset
from .dukemtmcreid import DukeMTMCreID
from .market1501 import Market1501
from .occ_duke import OCC_DukeMTMCreID
from .occluded_reid import OccludedREID
from .sampler import RandomIdentitySampler
from .sampler_ddp import RandomIdentitySampler_DDP


DATASETS = {
    "market1501": Market1501,
    "dukemtmc": DukeMTMCreID,
    "occ_duke": OCC_DukeMTMCreID,
    "occluded_reid": OccludedREID,
}


def train_collate_fn(batch):
    images, pids, camids, viewids, _ = zip(*batch)
    return (
        torch.stack(images),
        torch.tensor(pids, dtype=torch.int64),
        torch.tensor(camids, dtype=torch.int64),
        torch.tensor(viewids, dtype=torch.int64),
    )


def val_collate_fn(batch):
    images, pids, camids, viewids, paths = zip(*batch)
    return (
        torch.stack(images),
        pids,
        camids,
        torch.tensor(camids, dtype=torch.int64),
        torch.tensor(viewids, dtype=torch.int64),
        paths,
    )


def make_dataloader(cfg):
    if cfg.DATASETS.NAMES not in DATASETS:
        raise KeyError(f"Unsupported dataset: {cfg.DATASETS.NAMES}")

    train_transform = transforms.Compose(
        [
            transforms.Resize(cfg.INPUT.SIZE_TRAIN, interpolation=3),
            transforms.RandomHorizontalFlip(p=cfg.INPUT.PROB),
            transforms.Pad(cfg.INPUT.PADDING),
            transforms.RandomCrop(cfg.INPUT.SIZE_TRAIN),
            transforms.ToTensor(),
            transforms.Normalize(cfg.INPUT.PIXEL_MEAN, cfg.INPUT.PIXEL_STD),
            RandomErasing(
                probability=cfg.INPUT.RE_PROB,
                mode="pixel",
                max_count=1,
                device="cpu",
            ),
        ]
    )
    test_transform = transforms.Compose(
        [
            transforms.Resize(cfg.INPUT.SIZE_TEST),
            transforms.ToTensor(),
            transforms.Normalize(cfg.INPUT.PIXEL_MEAN, cfg.INPUT.PIXEL_STD),
        ]
    )

    dataset = DATASETS[cfg.DATASETS.NAMES](root=cfg.DATASETS.ROOT_DIR)
    train_set = ImageDataset(dataset.train, train_transform)
    stage1_set = ImageDataset(dataset.train, test_transform)

    if cfg.MODEL.DIST_TRAIN:
        mini_batch = cfg.SOLVER.STAGE2.IMS_PER_BATCH // dist.get_world_size()
        sampler = RandomIdentitySampler_DDP(
            dataset.train,
            cfg.SOLVER.STAGE2.IMS_PER_BATCH,
            cfg.DATALOADER.NUM_INSTANCE,
        )
        batch_sampler = torch.utils.data.BatchSampler(sampler, mini_batch, True)
        stage2_loader = DataLoader(
            train_set,
            num_workers=cfg.DATALOADER.NUM_WORKERS,
            batch_sampler=batch_sampler,
            collate_fn=train_collate_fn,
            pin_memory=True,
        )
    else:
        sampler = RandomIdentitySampler(
            dataset.train,
            cfg.SOLVER.STAGE2.IMS_PER_BATCH,
            cfg.DATALOADER.NUM_INSTANCE,
        )
        stage2_loader = DataLoader(
            train_set,
            batch_size=cfg.SOLVER.STAGE2.IMS_PER_BATCH,
            sampler=sampler,
            num_workers=cfg.DATALOADER.NUM_WORKERS,
            collate_fn=train_collate_fn,
        )

    stage1_loader = DataLoader(
        stage1_set,
        batch_size=cfg.SOLVER.STAGE1.IMS_PER_BATCH,
        shuffle=True,
        num_workers=cfg.DATALOADER.NUM_WORKERS,
        collate_fn=train_collate_fn,
    )
    val_set = ImageDataset(dataset.query + dataset.gallery, test_transform)
    val_loader = DataLoader(
        val_set,
        batch_size=cfg.TEST.IMS_PER_BATCH,
        shuffle=False,
        num_workers=cfg.DATALOADER.NUM_WORKERS,
        collate_fn=val_collate_fn,
    )

    return (
        stage2_loader,
        stage1_loader,
        val_loader,
        len(dataset.query),
        dataset.num_train_pids,
        dataset.num_train_cams,
        dataset.num_train_vids,
    )
