import argparse
import os

from config import cfg
from datasets.make_dataloader import make_dataloader
from model.cover_reid import make_model
from processor.stage2 import do_inference
from utils.logger import setup_logger


def parse_args():
    parser = argparse.ArgumentParser(description="Evaluate COVER-ReID")
    parser.add_argument("--config-file", default="configs/cover_occ_duke.yml")
    parser.add_argument("opts", default=None, nargs=argparse.REMAINDER)
    return parser.parse_args()


def main():
    args = parse_args()
    cfg.merge_from_file(args.config_file)
    cfg.merge_from_list(args.opts)
    cfg.freeze()
    if not cfg.TEST.WEIGHT:
        raise ValueError("Set TEST.WEIGHT to a COVER checkpoint.")

    os.environ.setdefault("CUDA_VISIBLE_DEVICES", cfg.MODEL.DEVICE_ID)
    os.makedirs(cfg.OUTPUT_DIR, exist_ok=True)
    logger = setup_logger("cover", cfg.OUTPUT_DIR, if_train=False)
    logger.info("Configuration:\n%s", cfg)

    loaders = make_dataloader(cfg)
    val_loader = loaders[2]
    num_query, num_classes, camera_num, view_num = loaders[3:]
    model = make_model(cfg, num_classes, camera_num, view_num)
    model.load_param(cfg.TEST.WEIGHT)
    do_inference(cfg, model, val_loader, num_query)


if __name__ == "__main__":
    main()
