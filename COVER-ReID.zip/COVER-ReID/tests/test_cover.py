import random
import unittest

import torch
import torch.nn as nn

from config import cfg
from model.cover import CounterfactualVisiblePartAggregation
from processor.cover import (
    build_counterfactual_batch,
    mask_to_visibility,
    visibility_supervision,
)


class VisibilityModel(nn.Module):
    def __init__(self, cvpa):
        super().__init__()
        self.cvpa = cvpa

    def visibility_logits(self, tokens):
        return self.cvpa.visibility_logits(tokens)


class CoverMechanismTest(unittest.TestCase):
    def setUp(self):
        self.cfg = cfg.clone()
        self.cfg.defrost()
        self.cfg.COVER.OCCLUSION.PROB = 1.0
        self.cfg.COVER.OCCLUSION.NUM_SOURCE_CANDIDATES = 2
        self.cfg.COVER.OCCLUSION.NUM_TARGET_CANDIDATES = 2
        self.cfg.COVER.OCCLUSION.TOPK = 2
        self.cfg.freeze()
        random.seed(7)
        torch.manual_seed(7)

    def test_counterfactual_batch_produces_aligned_masks(self):
        images = torch.stack([torch.zeros(3, 32, 16), torch.ones(3, 32, 16)])
        labels = torch.tensor([0, 1])
        tokens = torch.randn(2, 8, 4)
        global_features = torch.randn(2, 4)
        text_features = {
            "source_positive": torch.randn(2, 4),
            "source_negative": torch.randn(2, 4),
            "target_positive": torch.randn(2, 4),
            "target_negative": torch.randn(1, 4),
        }
        text_features = {
            key: torch.nn.functional.normalize(value, dim=-1)
            for key, value in text_features.items()
        }

        counterfactual, mask, stats = build_counterfactual_batch(
            images,
            labels,
            tokens,
            global_features,
            text_features,
            self.cfg,
            grid_size=(4, 2),
        )

        self.assertEqual(stats["count"], 2)
        self.assertGreater(mask.sum().item(), 0)
        changed = (counterfactual - images).abs().sum(dim=1, keepdim=True) > 0
        self.assertTrue(torch.equal(changed, mask.bool()))

    def test_mask_projection_preserves_fractional_visibility(self):
        mask = torch.zeros(1, 1, 8, 4)
        mask[:, :, :3, :] = 1.0
        visibility, occlusion = mask_to_visibility(mask, (4, 2))

        self.assertEqual(tuple(visibility.shape), (1, 8))
        self.assertTrue(torch.allclose(visibility + occlusion, torch.ones_like(visibility)))
        self.assertTrue(((visibility > 0) & (visibility < 1)).any())

    def test_cvpa_and_visibility_loss_are_differentiable(self):
        cvpa = CounterfactualVisiblePartAggregation(
            token_dim=8,
            hidden_dim=4,
            grid_size=(4, 2),
            part_ranges=self.cfg.COVER.CVPA.PART_RANGES,
            part_scale=0.5,
            min_visibility=0.05,
        )
        clean_tokens = torch.randn(2, 8, 8, requires_grad=True)
        counterfactual_tokens = torch.randn(2, 8, 8, requires_grad=True)
        feature, stats = cvpa(counterfactual_tokens, return_stats=True)
        mask = torch.zeros(2, 1, 16, 8)
        mask[:, :, 4:10, 2:6] = 1.0

        loss, _ = visibility_supervision(
            VisibilityModel(cvpa),
            clean_tokens,
            counterfactual_tokens,
            mask,
            self.cfg,
            grid_size=(4, 2),
        )
        (feature.mean() + loss).backward()

        self.assertEqual(tuple(feature.shape), (2, 32))
        self.assertEqual(tuple(stats["part_confidence"].shape), (2, 4))
        self.assertIsNotNone(cvpa.visibility_head[-1].weight.grad)


if __name__ == "__main__":
    unittest.main()
