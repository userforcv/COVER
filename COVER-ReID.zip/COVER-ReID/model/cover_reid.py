import torch
import torch.nn as nn
from timm.models.layers import trunc_normal_

from .clip import clip
from .cover import CounterfactualVisiblePartAggregation


def weights_init_kaiming(module):
    classname = module.__class__.__name__
    if "Linear" in classname:
        nn.init.kaiming_normal_(module.weight, a=0, mode="fan_out")
        if module.bias is not None:
            nn.init.constant_(module.bias, 0.0)
    elif "BatchNorm" in classname and module.affine:
        nn.init.constant_(module.weight, 1.0)
        nn.init.constant_(module.bias, 0.0)


def weights_init_classifier(module):
    if "Linear" in module.__class__.__name__:
        nn.init.normal_(module.weight, std=0.001)
        if module.bias is not None:
            nn.init.constant_(module.bias, 0.0)


class TextEncoder(nn.Module):
    def __init__(self, clip_model):
        super().__init__()
        self.transformer = clip_model.transformer
        self.positional_embedding = clip_model.positional_embedding
        self.ln_final = clip_model.ln_final
        self.text_projection = clip_model.text_projection
        self.dtype = clip_model.dtype

    def forward(self, prompts, tokenized_prompts):
        features = prompts + self.positional_embedding.type(self.dtype)
        features = self.transformer(features.permute(1, 0, 2)).permute(1, 0, 2)
        features = self.ln_final(features).type(self.dtype)
        indices = tokenized_prompts.argmax(dim=-1)
        rows = torch.arange(features.shape[0], device=features.device)
        return features[rows, indices] @ self.text_projection


class PromptLearner(nn.Module):
    def __init__(self, num_classes, dtype, token_embedding):
        super().__init__()
        context = "A photo of a X X X X person."
        tokenized_prompts = clip.tokenize(context).cuda()
        with torch.no_grad():
            embedding = token_embedding(tokenized_prompts).type(dtype)

        num_context_tokens = 4
        num_class_tokens = 4
        class_context = torch.empty(num_classes, num_class_tokens, 512, dtype=dtype)
        nn.init.normal_(class_context, std=0.02)
        self.cls_ctx = nn.Parameter(class_context)
        self.register_buffer("tokenized_prompts", tokenized_prompts)
        self.register_buffer("token_prefix", embedding[:, :num_context_tokens + 1])
        self.register_buffer(
            "token_suffix", embedding[:, num_context_tokens + 1 + num_class_tokens:]
        )

    def forward(self, labels):
        batch_size = labels.shape[0]
        return torch.cat(
            [
                self.token_prefix.expand(batch_size, -1, -1),
                self.cls_ctx[labels],
                self.token_suffix.expand(batch_size, -1, -1),
            ],
            dim=1,
        )


class COVER(nn.Module):
    """ViT-B/16 ReID encoder with Counterfactual Visible-Part Aggregation."""

    def __init__(self, num_classes, camera_num, view_num, cfg):
        super().__init__()
        if cfg.MODEL.NAME != "ViT-B-16":
            raise ValueError("COVER currently supports the ViT-B/16 backbone.")

        self.model_name = cfg.MODEL.NAME
        self.neck_feat = cfg.TEST.NECK_FEAT
        self.num_classes = num_classes
        self.camera_num = camera_num
        self.view_num = view_num
        self.sie_coe = cfg.MODEL.SIE_COE
        self.use_camera_sie = bool(cfg.MODEL.SIE_CAMERA)
        self.use_view_sie = bool(cfg.MODEL.SIE_VIEW)
        self.in_planes = 768
        self.in_planes_proj = 512

        self.h_resolution = (cfg.INPUT.SIZE_TRAIN[0] - 16) // cfg.MODEL.STRIDE_SIZE[0] + 1
        self.w_resolution = (cfg.INPUT.SIZE_TRAIN[1] - 16) // cfg.MODEL.STRIDE_SIZE[1] + 1
        clip_model = load_clip_to_cpu(
            self.model_name,
            self.h_resolution,
            self.w_resolution,
            cfg.MODEL.STRIDE_SIZE[0],
        )
        clip_model.to("cuda")
        self.image_encoder = clip_model.visual
        self.token_embedding = clip_model.token_embedding
        self.text_encoder = TextEncoder(clip_model)
        self.prompt_learner = PromptLearner(
            num_classes, clip_model.dtype, clip_model.token_embedding
        )

        if self.use_camera_sie and self.use_view_sie:
            self.cv_embed = nn.Parameter(torch.zeros(camera_num * view_num, self.in_planes))
            trunc_normal_(self.cv_embed, std=0.02)
        elif self.use_camera_sie:
            self.cv_embed = nn.Parameter(torch.zeros(camera_num, self.in_planes))
            trunc_normal_(self.cv_embed, std=0.02)
        elif self.use_view_sie:
            self.cv_embed = nn.Parameter(torch.zeros(view_num, self.in_planes))
            trunc_normal_(self.cv_embed, std=0.02)

        self.classifier = nn.Linear(self.in_planes, num_classes, bias=False)
        self.classifier_proj = nn.Linear(self.in_planes_proj, num_classes, bias=False)
        self.classifier.apply(weights_init_classifier)
        self.classifier_proj.apply(weights_init_classifier)
        self.bottleneck = nn.BatchNorm1d(self.in_planes)
        self.bottleneck_proj = nn.BatchNorm1d(self.in_planes_proj)
        self.bottleneck.bias.requires_grad_(False)
        self.bottleneck_proj.bias.requires_grad_(False)
        self.bottleneck.apply(weights_init_kaiming)
        self.bottleneck_proj.apply(weights_init_kaiming)

        cvpa_cfg = cfg.COVER.CVPA
        self.cvpa = CounterfactualVisiblePartAggregation(
            token_dim=self.in_planes_proj,
            hidden_dim=cvpa_cfg.VIS_HIDDEN_DIM,
            grid_size=(self.h_resolution, self.w_resolution),
            part_ranges=cvpa_cfg.PART_RANGES,
            part_scale=cvpa_cfg.PART_SCALE,
            min_visibility=cvpa_cfg.MIN_VISIBILITY,
            eps=cvpa_cfg.EPS,
        )
        cvpa_dim = self.in_planes_proj * self.cvpa.output_dim_multiplier
        self.bottleneck_cvpa = nn.BatchNorm1d(cvpa_dim)
        self.bottleneck_cvpa.bias.requires_grad_(False)
        self.bottleneck_cvpa.apply(weights_init_kaiming)
        self.classifier_cvpa = nn.Linear(cvpa_dim, num_classes, bias=False)
        self.classifier_cvpa.apply(weights_init_classifier)

    def encode_text_tokens(self, tokenized_prompts):
        prompts = self.token_embedding(tokenized_prompts).type(self.text_encoder.dtype)
        return self.text_encoder(prompts, tokenized_prompts)

    def visibility_logits(self, patch_tokens):
        return self.cvpa.visibility_logits(patch_tokens)

    def _side_information(self, cam_label, view_label):
        if self.use_camera_sie and self.use_view_sie:
            return self.sie_coe * self.cv_embed[cam_label * self.view_num + view_label]
        if self.use_camera_sie:
            return self.sie_coe * self.cv_embed[cam_label]
        if self.use_view_sie:
            return self.sie_coe * self.cv_embed[view_label]
        return None

    def forward(
        self,
        x=None,
        label=None,
        get_image=False,
        get_text=False,
        cam_label=None,
        view_label=None,
        return_patch_tokens=False,
        return_cvpa_stats=False,
    ):
        if get_text:
            prompts = self.prompt_learner(label)
            return self.text_encoder(prompts, self.prompt_learner.tokenized_prompts)

        if get_image:
            _, _, projected = self.image_encoder(x)
            if return_patch_tokens:
                return projected[:, 0], projected[:, 1:]
            return projected[:, 0]

        side_information = self._side_information(cam_label, view_label)
        features_last, features, projected = self.image_encoder(x, side_information)
        global_last = features_last[:, 0]
        global_feature = features[:, 0]
        projected_feature = projected[:, 0]
        patch_tokens = projected[:, 1:]

        if return_cvpa_stats:
            cvpa_feature, cvpa_stats = self.cvpa(patch_tokens, return_stats=True)
        else:
            cvpa_feature = self.cvpa(patch_tokens)
            cvpa_stats = None

        global_bn = self.bottleneck(global_feature)
        projected_bn = self.bottleneck_proj(projected_feature)
        cvpa_bn = self.bottleneck_cvpa(cvpa_feature)

        if self.training:
            scores = [
                self.classifier(global_bn),
                self.classifier_proj(projected_bn),
                self.classifier_cvpa(cvpa_bn),
            ]
            metric_features = [
                global_last,
                global_feature,
                projected_feature,
                cvpa_feature,
            ]
            output = (scores, metric_features, projected_feature)
            if return_patch_tokens:
                output += (patch_tokens,)
            if return_cvpa_stats:
                output += (cvpa_stats,)
            return output

        if self.neck_feat == "after":
            descriptor = torch.cat([global_bn, projected_bn, cvpa_bn], dim=1)
        else:
            descriptor = torch.cat([global_feature, projected_feature, cvpa_feature], dim=1)
        if return_patch_tokens:
            return descriptor, patch_tokens
        if return_cvpa_stats:
            return descriptor, cvpa_stats
        return descriptor

    def load_param(self, trained_path):
        checkpoint = torch.load(trained_path, map_location="cpu")
        model_state = self.state_dict()
        skipped = []
        for original_key, value in checkpoint.items():
            key = original_key.replace("module.", "")
            if key not in model_state or model_state[key].shape != value.shape:
                skipped.append(key)
                continue
            model_state[key].copy_(value)
        print(f"Loaded checkpoint from {trained_path}")
        if skipped:
            print(f"Skipped {len(skipped)} incompatible checkpoint entries.")


def make_model(cfg, num_class, camera_num, view_num):
    return COVER(num_class, camera_num, view_num, cfg)


def load_clip_to_cpu(backbone_name, h_resolution, w_resolution, vision_stride_size):
    model_path = clip._download(clip._MODELS[backbone_name])
    try:
        model = torch.jit.load(model_path, map_location="cpu").eval()
        state_dict = None
    except RuntimeError:
        state_dict = torch.load(model_path, map_location="cpu")
        model = None
    return clip.build_model(
        state_dict or model.state_dict(),
        h_resolution,
        w_resolution,
        vision_stride_size,
    )
