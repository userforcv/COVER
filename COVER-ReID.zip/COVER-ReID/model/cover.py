import math

import torch
import torch.nn as nn
import torch.nn.functional as F


def _init_linear(module):
    if isinstance(module, nn.Linear):
        nn.init.kaiming_normal_(module.weight, a=0, mode="fan_out")
        if module.bias is not None:
            nn.init.constant_(module.bias, 0.0)


class CounterfactualVisiblePartAggregation(nn.Module):
    """Mask-supervised token reliability and visible-part aggregation."""

    def __init__(
        self,
        token_dim,
        hidden_dim,
        grid_size,
        part_ranges,
        part_scale=0.5,
        min_visibility=0.05,
        eps=1e-6,
    ):
        super().__init__()
        self.grid_h, self.grid_w = grid_size
        self.part_ranges = [tuple(part) for part in part_ranges]
        self.part_scale = float(part_scale)
        self.min_visibility = float(min_visibility)
        self.eps = float(eps)

        self.visibility_head = nn.Sequential(
            nn.LayerNorm(token_dim),
            nn.Linear(token_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, 1),
        )
        self.visibility_head.apply(_init_linear)
        nn.init.constant_(self.visibility_head[-1].weight, 0.0)
        nn.init.constant_(self.visibility_head[-1].bias, 0.0)

    @property
    def output_dim_multiplier(self):
        return len(self.part_ranges)

    def visibility_logits(self, patch_tokens):
        return self.visibility_head(patch_tokens.float()).squeeze(-1)

    def forward(self, patch_tokens, return_stats=False):
        if patch_tokens.ndim != 3:
            raise ValueError("CVPA expects patch tokens with shape [B, N, C].")
        if patch_tokens.shape[1] != self.grid_h * self.grid_w:
            raise ValueError(
                "Patch-token count does not match the configured grid: "
                f"{patch_tokens.shape[1]} != {self.grid_h} x {self.grid_w}."
            )

        tokens = patch_tokens.float()
        visibility_logits = self.visibility_logits(patch_tokens)
        reliability = torch.sigmoid(visibility_logits).clamp(0.0, 1.0)
        features = []
        confidences = []

        for start, end in self.part_ranges:
            row_start = max(0, min(int(math.floor(start * self.grid_h)), self.grid_h - 1))
            row_end = max(row_start + 1, min(int(math.ceil(end * self.grid_h)), self.grid_h))
            token_start = row_start * self.grid_w
            token_end = row_end * self.grid_w

            part_tokens = tokens[:, token_start:token_end]
            part_reliability = reliability[:, token_start:token_end]
            pooled = (part_reliability.unsqueeze(-1) * part_tokens).sum(dim=1)
            pooled = pooled / (part_reliability.sum(dim=1, keepdim=True) + self.eps)
            pooled = F.normalize(pooled, dim=-1)

            confidence = part_reliability.mean(dim=1, keepdim=True)
            confidence = confidence.clamp(min=self.min_visibility)
            confidences.append(confidence)
            features.append(self.part_scale * confidence * pooled)

        feature = torch.cat(features, dim=-1).to(dtype=patch_tokens.dtype)
        if not return_stats:
            return feature

        return feature, {
            "visibility_logits": visibility_logits,
            "reliability": reliability,
            "part_confidence": torch.cat(confidences, dim=1),
        }
